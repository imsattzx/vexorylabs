(() => {
  const root = document.documentElement;
  const header = document.querySelector('.site-header');
  const progress = document.querySelector('.scroll-progress');
  const waFloat = document.querySelector('.whatsapp-float');
  const nav = document.querySelector('.main-nav');
  const menuButton = document.querySelector('.menu-toggle');
  const navLinks = nav ? [...nav.querySelectorAll('a')] : [];
  const sections = navLinks
    .map(link => document.querySelector(link.getAttribute('href')))
    .filter(Boolean);
  const year = document.getElementById('year');
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  const clamp = (v, min = 0, max = 1) => Math.min(max, Math.max(min, v));

  if (window.lucide) window.lucide.createIcons();
  if (year) year.textContent = new Date().getFullYear();

  /* ---------- Títulos: separa em palavras para animar ---------- */
  const splitWords = el => {
    let n = 0;
    const makeWord = node => {
      const w = document.createElement('span');
      const wi = document.createElement('span');
      w.className = 'w';
      wi.className = 'wi';
      wi.style.setProperty('--w', n++);
      w.appendChild(wi);
      return { w, wi, node };
    };
    const walk = parent => {
      [...parent.childNodes].forEach(child => {
        if (child.nodeType === 3) {
          const frag = document.createDocumentFragment();
          child.textContent.split(/(\s+)/).forEach(part => {
            if (!part) return;
            if (/^\s+$/.test(part)) { frag.appendChild(document.createTextNode(' ')); return; }
            const { w, wi } = makeWord();
            wi.textContent = part;
            frag.appendChild(w);
          });
          parent.replaceChild(frag, child);
        } else if (child.nodeType === 1 && child.tagName !== 'BR') {
          if (child.classList.contains('gradient-text')) {
            const { w, wi } = makeWord();
            parent.replaceChild(w, child);
            wi.appendChild(child);
          } else {
            walk(child);
          }
        }
      });
    };
    walk(el);
    el.classList.add('split');
  };
  if (!reducedMotion) {
    document.querySelectorAll('.intro-heading h2, .section-heading h2, .contact-content h2, .manifesto-text')
      .forEach(splitWords);
  }

  /* ---------- Reveal (só começa depois da tela de entrada) ---------- */
  const revealItems = [...document.querySelectorAll('.reveal')];
  let started = false;
  const startReveals = () => {
    if (started) return;
    started = true;
    root.classList.add('is-loaded');
    if (reducedMotion || !('IntersectionObserver' in window)) {
      revealItems.forEach(item => item.classList.add('in'));
      return;
    }
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -36px 0px' });
    revealItems.forEach(item => revealObserver.observe(item));
  };

  /* ---------- Tela de entrada ---------- */
  const loader = document.querySelector('.loader');
  if (loader && root.classList.contains('is-loading') && !reducedMotion) {
    const MIN = 1300, MAX = 4000, t0 = performance.now();
    const loaded = new Promise(r =>
      document.readyState === 'complete' ? r() : window.addEventListener('load', r, { once: true }));
    const fonts = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
    Promise.race([Promise.all([loaded, fonts]), new Promise(r => setTimeout(r, MAX))]).then(() => {
      setTimeout(() => {
        loader.classList.add('done');
        root.classList.remove('is-loading');
        try { sessionStorage.setItem('vx-seen', '1'); } catch (_) {}
        setTimeout(startReveals, 450);
        setTimeout(() => loader.remove(), 1400);
      }, Math.max(0, MIN - (performance.now() - t0)));
    });
  } else {
    if (loader) loader.remove();
    startReveals();
  }

  /* ---------- Navegação ---------- */
  const moveIndicator = link => {
    const indicator = nav && nav.querySelector('.nav-indicator');
    if (!indicator || !link) return;
    indicator.style.left = `${link.offsetLeft}px`;
    indicator.style.width = `${link.offsetWidth}px`;
  };

  const updateActiveLink = () => {
    const marker = window.scrollY + window.innerHeight * 0.35;
    let current = sections[0] && sections[0].id;
    sections.forEach(section => {
      if (section.offsetTop <= marker) current = section.id;
    });
    navLinks.forEach(link => {
      const active = link.getAttribute('href') === `#${current}`;
      link.classList.toggle('active', active);
      if (active) moveIndicator(link);
    });
  };

  /* ---------- Efeitos ligados ao scroll ---------- */
  const bgScene = document.querySelector('.bg-scene');
  const hero = document.querySelector('.hero');
  const projectCards = [...document.querySelectorAll('.project-card')];
  const manifesto = document.querySelector('.manifesto-card');
  const marqueeTrack = document.querySelector('.marquee-track');
  let lastY = window.scrollY;
  let boost = 0, boostRaf = 0, marqueeAnim = null;

  const updateParallax = () => {
    const vh = window.innerHeight;
    const y = window.scrollY;
    if (bgScene) bgScene.style.setProperty('--sy', y.toFixed(1));
    if (hero) hero.style.setProperty('--hero-p', clamp(y / (vh * 0.9)).toFixed(4));
    projectCards.forEach(card => {
      const r = card.getBoundingClientRect();
      if (r.bottom < -100 || r.top > vh + 100) return;
      const p = clamp((r.top + r.height / 2 - vh / 2) / (vh / 2 + r.height / 2), -1, 1);
      card.style.setProperty('--py', p.toFixed(3));
    });
    if (manifesto) {
      const r = manifesto.getBoundingClientRect();
      manifesto.style.setProperty('--mp', clamp((vh - r.top) / (vh * 0.75)).toFixed(3));
    }
  };

  // o marquee acelera conforme a velocidade do scroll
  const tickMarquee = () => {
    if (!marqueeAnim && marqueeTrack && marqueeTrack.getAnimations) {
      marqueeAnim = marqueeTrack.getAnimations()[0] || null;
    }
    boost *= 0.92;
    if (marqueeAnim) marqueeAnim.playbackRate = 1 + boost;
    if (boost > 0.02) {
      boostRaf = requestAnimationFrame(tickMarquee);
    } else {
      boost = 0;
      if (marqueeAnim) marqueeAnim.playbackRate = 1;
      boostRaf = 0;
    }
  };

  const updateScrollState = () => {
    const scrollY = window.scrollY;
    const maxScroll = root.scrollHeight - window.innerHeight;
    const dy = scrollY - lastY;
    lastY = scrollY;

    if (progress) progress.style.setProperty('--progress', maxScroll > 0 ? scrollY / maxScroll : 0);
    if (header) {
      header.classList.toggle('scrolled', scrollY > 20);
      if (!reducedMotion && !(nav && nav.classList.contains('open'))) {
        if (scrollY > 480 && dy > 6) header.classList.add('hide');
        else if (dy < -4 || scrollY <= 480) header.classList.remove('hide');
      }
    }
    if (waFloat) waFloat.classList.toggle('show', scrollY > window.innerHeight * 0.5);
    updateActiveLink();

    if (!reducedMotion) {
      updateParallax();
      boost = Math.min(boost + Math.abs(dy) * 0.04, 6);
      if (!boostRaf && marqueeTrack) boostRaf = requestAnimationFrame(tickMarquee);
    }
  };

  let scrollPending = false;
  window.addEventListener('scroll', () => {
    if (scrollPending) return;
    scrollPending = true;
    requestAnimationFrame(() => {
      updateScrollState();
      scrollPending = false;
    });
  }, { passive: true });

  window.addEventListener('resize', () => {
    moveIndicator(nav && nav.querySelector('a.active'));
    updateScrollState();
  });
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(() => moveIndicator(nav && nav.querySelector('a.active')));
  }

  /* ---------- Menu mobile ---------- */
  const closeMenu = () => {
    if (!nav || !menuButton) return;
    nav.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.setAttribute('aria-label', 'Abrir menu');
  };

  if (nav && menuButton) {
    menuButton.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      menuButton.setAttribute('aria-expanded', String(open));
      menuButton.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu');
      if (open && header) header.classList.remove('hide');
    });
    navLinks.forEach(link => link.addEventListener('click', closeMenu));
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape') closeMenu();
    });
  }

  /* ---------- Interações com mouse (só desktop) ---------- */
  if (finePointer && !reducedMotion) {
    // spotlight + tilt nos cards
    document.querySelectorAll('.service-card, .value-item, .project-card').forEach(card => {
      const tilt = card.classList.contains('project-card');
      card.addEventListener('pointermove', e => {
        const r = card.getBoundingClientRect();
        const x = e.clientX - r.left, y = e.clientY - r.top;
        card.style.setProperty('--mx', `${x}px`);
        card.style.setProperty('--my', `${y}px`);
        if (tilt) {
          card.style.setProperty('--ry', `${((x / r.width - 0.5) * 8).toFixed(2)}deg`);
          card.style.setProperty('--rx', `${((0.5 - y / r.height) * 8).toFixed(2)}deg`);
        }
      });
      card.addEventListener('pointerleave', () => {
        if (tilt) { card.style.setProperty('--rx', '0deg'); card.style.setProperty('--ry', '0deg'); }
      });
    });

    // janela de código inclina com o mouse
    const heroVisual = document.querySelector('.hero-visual');
    const codeWin = document.querySelector('.code-window');
    if (heroVisual && codeWin) {
      heroVisual.addEventListener('pointermove', e => {
        const r = heroVisual.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - 0.5;
        const y = (e.clientY - r.top) / r.height - 0.5;
        codeWin.style.setProperty('--ry', `${(x * 12).toFixed(2)}deg`);
        codeWin.style.setProperty('--rx', `${(-y * 9).toFixed(2)}deg`);
      });
      heroVisual.addEventListener('pointerleave', () => {
        codeWin.style.setProperty('--rx', '0deg');
        codeWin.style.setProperty('--ry', '0deg');
      });
    }

    // botões magnéticos
    document.querySelectorAll('.button').forEach(btn => {
      btn.addEventListener('pointermove', e => {
        const r = btn.getBoundingClientRect();
        const x = e.clientX - (r.left + r.width / 2);
        const y = e.clientY - (r.top + r.height / 2);
        btn.style.translate = `${(x * 0.18).toFixed(1)}px ${(y * 0.25).toFixed(1)}px`;
      });
      btn.addEventListener('pointerleave', () => { btn.style.translate = ''; });
    });

    // brilho que segue o cursor
    const glow = document.createElement('div');
    glow.className = 'cursor-glow';
    glow.setAttribute('aria-hidden', 'true');
    document.body.appendChild(glow);
    let tx = 0, ty = 0, cx = 0, cy = 0, glowRaf = 0;
    const glowLoop = () => {
      cx += (tx - cx) * 0.12;
      cy += (ty - cy) * 0.12;
      glow.style.transform = `translate3d(${cx}px, ${cy}px, 0) translate(-50%, -50%)`;
      glowRaf = Math.abs(tx - cx) + Math.abs(ty - cy) > 0.5 ? requestAnimationFrame(glowLoop) : 0;
    };
    window.addEventListener('pointermove', e => {
      if (!glow.classList.contains('on')) { cx = tx = e.clientX; cy = ty = e.clientY; glow.classList.add('on'); }
      tx = e.clientX; ty = e.clientY;
      if (!glowRaf) glowRaf = requestAnimationFrame(glowLoop);
    }, { passive: true });
    document.addEventListener('pointerleave', () => glow.classList.remove('on'));
  }

  updateScrollState();
})();
